## EPS / TICK / TICK

execute if score #value eps_val_1 = 1 svl_value run function eps:run