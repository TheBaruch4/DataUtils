## EPS / RUN / CALL

execute as @e[type=!player] store result score @s x_eps_entity run data get entity @s Pos[0]
execute as @e[type=!player] store result score @s y_eps_entity run data get entity @s Pos[1]
execute as @e[type=!player] store result score @s z_eps_entity run data get entity @s Pos[2]

execute as @e[type=player] store result score @s x_eps_player run data get entity @s Pos[0]
execute as @e[type=player] store result score @s y_eps_player run data get entity @s Pos[1]
execute as @e[type=player] store result score @s z_eps_player run data get entity @s Pos[2]

execute as @e store result score @s x_eps_all run data get entity @s Pos[0]
execute as @e store result score @s y_eps_all run data get entity @s Pos[1]
execute as @e store result score @s z_eps_all run data get entity @s Pos[2]