## EPS / LOAD / LOAD

scoreboard objectives add x_eps_entity dummy
scoreboard objectives add y_eps_entity dummy
scoreboard objectives add z_eps_entity dummy

scoreboard objectives add x_eps_player dummy
scoreboard objectives add y_eps_player dummy
scoreboard objectives add z_eps_player dummy

scoreboard objectives add x_eps_all dummy
scoreboard objectives add y_eps_all dummy
scoreboard objectives add z_eps_all dummy

scoreboard objectives add eps_val_1 dummy