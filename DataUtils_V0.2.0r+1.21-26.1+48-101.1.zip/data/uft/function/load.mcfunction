## UFT / LOAD / LOAD

# Creates the scoreboard objective that stores all countdowns for uft
scoreboard objectives add uft_data dummy