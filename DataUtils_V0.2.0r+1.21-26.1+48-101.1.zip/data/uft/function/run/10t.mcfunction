## UFT/RUN / 10T / CALL

# Sets the counter for this function to "11", to reset it for the next counting cycle
scoreboard players set 10t uft_data 11

# Runs the functions specified to be run under the "10t" function tag
function #ufti:10t