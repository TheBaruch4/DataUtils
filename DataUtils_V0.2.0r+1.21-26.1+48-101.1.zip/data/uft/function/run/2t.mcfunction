## UFT/RUN / 2T / CALL

# Sets the counter for this function to "3", to reset it for the next counting cycle
scoreboard players set 2t uft_data 3

# Runs the functions specified to be run under the "2t" function tag
function #ufti:2t