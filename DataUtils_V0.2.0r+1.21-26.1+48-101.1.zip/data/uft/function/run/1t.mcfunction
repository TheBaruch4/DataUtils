## UFT/RUN / 1T / CALL

# Sets the counter for this function to "2", to reset it for the next counting cycle
scoreboard players set 1t uft_data 2

# Runs the functions specified to be run under the "1t" function tag
function #ufti:1t