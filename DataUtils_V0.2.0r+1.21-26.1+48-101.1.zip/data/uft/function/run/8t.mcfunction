## UFT/RUN / 8T / CALL

# Sets the counter for this function to "9", to reset it for the next counting cycle
scoreboard players set 8t uft_data 9

# Runs the functions specified to be run under the "8t" function tag
function #ufti:8t