## UFT/RUN / 11T / CALL

# Sets the counter for this function to "12", to reset it for the next counting cycle
scoreboard players set 11t uft_data 12

# Runs the functions specified to be run under the "11t" function tag
function #ufti:11t