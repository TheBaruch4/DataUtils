## UFT/RUN / 18T / CALL

# Sets the counter for this function to "19", to reset it for the next counting cycle
scoreboard players set 18t uft_data 19

# Runs the functions specified to be run under the "18t" function tag
function #ufti:18t