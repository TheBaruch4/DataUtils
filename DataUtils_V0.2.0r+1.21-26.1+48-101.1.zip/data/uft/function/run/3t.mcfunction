## UFT/RUN / 3T / CALL

# Sets the counter for this function to "4", to reset it for the next counting cycle
scoreboard players set 3t uft_data 4

# Runs the functions specified to be run under the "3t" function tag
function #ufti:3t