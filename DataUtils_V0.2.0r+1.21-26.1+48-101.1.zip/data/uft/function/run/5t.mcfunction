## UFT/RUN / 5T / CALL

# Sets the counter for this function to "6", to reset it for the next counting cycle
scoreboard players set 5t uft_data 6

# Runs the functions specified to be run under the "5t" function tag
function #ufti:5t