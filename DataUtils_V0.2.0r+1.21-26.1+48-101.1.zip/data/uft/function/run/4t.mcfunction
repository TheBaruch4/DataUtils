## UFT/RUN / 4T / CALL

# Sets the counter for this function to "5", to reset it for the next counting cycle
scoreboard players set 4t uft_data 5

# Runs the functions specified to be run under the "4t" function tag
function #ufti:4t