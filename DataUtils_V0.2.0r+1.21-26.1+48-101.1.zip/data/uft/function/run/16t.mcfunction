## UFT/RUN / 16T / CALL

# Sets the counter for this function to "17", to reset it for the next counting cycle
scoreboard players set 16t uft_data 17

# Runs the functions specified to be run under the "16t" function tag
function #ufti:16t