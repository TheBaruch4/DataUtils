## UFT/RUN / 19T / CALL

# Sets the counter for this function to "20", to reset it for the next counting cycle
scoreboard players set 19t uft_data 20

# Runs the functions specified to be run under the "19t" function tag
function #ufti:19t