## UFT/RUN / 15T / CALL

# Sets the counter for this function to "16", to reset it for the next counting cycle
scoreboard players set 15t uft_data 16

# Runs the functions specified to be run under the "15t" function tag
function #ufti:15t