## UFT/RUN / 20T / CALL

# Sets the counter for this function to "21", to reset it for the next counting cycle
scoreboard players set 20t uft_data 21

# Runs the functions specified to be run under the "20t" function tag
function #ufti:20t