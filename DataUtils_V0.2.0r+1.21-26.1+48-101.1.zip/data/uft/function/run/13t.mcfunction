## UFT/RUN / 13T / CALL

# Sets the counter for this function to "14", to reset it for the next counting cycle
scoreboard players set 13t uft_data 14

# Runs the functions specified to be run under the "13t" function tag
function #ufti:13t