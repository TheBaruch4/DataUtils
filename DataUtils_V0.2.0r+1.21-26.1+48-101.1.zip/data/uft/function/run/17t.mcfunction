## UFT/RUN / 17T / CALL

# Sets the counter for this function to "18", to reset it for the next counting cycle
scoreboard players set 17t uft_data 18

# Runs the functions specified to be run under the "17t" function tag
function #ufti:17t