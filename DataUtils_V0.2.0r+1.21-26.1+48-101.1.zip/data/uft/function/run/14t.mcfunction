## UFT/RUN / 14T / CALL

# Sets the counter for this function to "15", to reset it for the next counting cycle
scoreboard players set 14t uft_data 15

# Runs the functions specified to be run under the "14t" function tag
function #ufti:14t