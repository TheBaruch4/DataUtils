## UFT/RUN / 0T / CALL

# Sets the counter for this function to "1", to reset it for the next counting cycle
scoreboard players set 0t uft_data 1

# Runs the functions specified to be run under the "0t" function tag
function #ufti:0t