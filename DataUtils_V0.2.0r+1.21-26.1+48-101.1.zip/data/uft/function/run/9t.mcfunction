## UFT/RUN / 9T / CALL

# Sets the counter for this function to "10", to reset it for the next counting cycle
scoreboard players set 9t uft_data 10

# Runs the functions specified to be run under the "9t" function tag
function #ufti:9t