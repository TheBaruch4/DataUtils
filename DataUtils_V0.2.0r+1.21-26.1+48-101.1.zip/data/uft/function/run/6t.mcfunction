## UFT/RUN / 6T / CALL

# Sets the counter for this function to "7", to reset it for the next counting cycle
scoreboard players set 6t uft_data 7

# Runs the functions specified to be run under the "6t" function tag
function #ufti:6t