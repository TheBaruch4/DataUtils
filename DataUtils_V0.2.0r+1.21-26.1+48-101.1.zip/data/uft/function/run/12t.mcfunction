## UFT/RUN / 12T / CALL

# Sets the counter for this function to "13", to reset it for the next counting cycle
scoreboard players set 12t uft_data 13

# Runs the functions specified to be run under the "12t" function tag
function #ufti:12t