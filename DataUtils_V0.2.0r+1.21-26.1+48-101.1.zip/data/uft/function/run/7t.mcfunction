## UFT/RUN / 7T / CALL

# Sets the counter for this function to "8", to reset it for the next counting cycle
scoreboard players set 7t uft_data 8

# Runs the functions specified to be run under the "7t" function tag
function #ufti:7t