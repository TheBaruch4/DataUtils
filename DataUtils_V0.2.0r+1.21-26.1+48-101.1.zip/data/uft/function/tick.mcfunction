## UFT / TICK / TICK


# Next =>
# Subtracts "1" from the counter
scoreboard players operation 0t uft_data -= 1 svl_value

# If the score is "0", runs a function to run the appropriate commands and reset the counter
execute if score 0t uft_data <= 0 svl_value run function uft:run/0t



# Next =>
# Subtracts "1" from the counter
scoreboard players operation 1t uft_data -= 1 svl_value

# If the score is "0", runs a function to run the appropriate commands and reset the counter
execute if score 1t uft_data <= 0 svl_value run function uft:run/1t



# Next =>
# Subtracts "1" from the counter
scoreboard players operation 2t uft_data -= 1 svl_value

# If the score is "0", runs a function to run the appropriate commands and reset the counter
execute if score 2t uft_data <= 0 svl_value run function uft:run/2t



# Next =>
# Subtracts "1" from the counter
scoreboard players operation 3t uft_data -= 1 svl_value

# If the score is "0", runs a function to run the appropriate commands and reset the counter
execute if score 3t uft_data <= 0 svl_value run function uft:run/3t



# Next =>
# Subtracts "1" from the counter
scoreboard players operation 4t uft_data -= 1 svl_value

# If the score is "0", runs a function to run the appropriate commands and reset the counter
execute if score 4t uft_data <= 0 svl_value run function uft:run/4t



# Next =>
# Subtracts "1" from the counter
scoreboard players operation 5t uft_data -= 1 svl_value

# If the score is "0", runs a function to run the appropriate commands and reset the counter
execute if score 5t uft_data <= 0 svl_value run function uft:run/5t



# Next =>
# Subtracts "1" from the counter
scoreboard players operation 6t uft_data -= 1 svl_value

# If the score is "0", runs a function to run the appropriate commands and reset the counter
execute if score 6t uft_data <= 0 svl_value run function uft:run/6t



# Next =>
# Subtracts "1" from the counter
scoreboard players operation 7t uft_data -= 1 svl_value

# If the score is "0", runs a function to run the appropriate commands and reset the counter
execute if score 7t uft_data <= 0 svl_value run function uft:run/7t



# Next =>
# Subtracts "1" from the counter
scoreboard players operation 8t uft_data -= 1 svl_value

# If the score is "0", runs a function to run the appropriate commands and reset the counter
execute if score 8t uft_data <= 0 svl_value run function uft:run/8t



# Next =>
# Subtracts "1" from the counter
scoreboard players operation 9t uft_data -= 1 svl_value

# If the score is "0", runs a function to run the appropriate commands and reset the counter
execute if score 9t uft_data <= 0 svl_value run function uft:run/9t



# Next =>
# Subtracts "1" from the counter
scoreboard players operation 10t uft_data -= 1 svl_value

# If the score is "0", runs a function to run the appropriate commands and reset the counter
execute if score 10t uft_data <= 0 svl_value run function uft:run/10t



# Next =>
# Subtracts "1" from the counter
scoreboard players operation 11t uft_data -= 1 svl_value

# If the score is "0", runs a function to run the appropriate commands and reset the counter
execute if score 11t uft_data <= 0 svl_value run function uft:run/11t



# Next =>
# Subtracts "1" from the counter
scoreboard players operation 12t uft_data -= 1 svl_value

# If the score is "0", runs a function to run the appropriate commands and reset the counter
execute if score 12t uft_data <= 0 svl_value run function uft:run/12t



# Next =>
# Subtracts "1" from the counter
scoreboard players operation 13t uft_data -= 1 svl_value

# If the score is "0", runs a function to run the appropriate commands and reset the counter
execute if score 13t uft_data <= 0 svl_value run function uft:run/13t



# Next =>
# Subtracts "1" from the counter
scoreboard players operation 14t uft_data -= 1 svl_value

# If the score is "0", runs a function to run the appropriate commands and reset the counter
execute if score 14t uft_data <= 0 svl_value run function uft:run/14t



# Next =>
# Subtracts "1" from the counter
scoreboard players operation 15t uft_data -= 1 svl_value

# If the score is "0", runs a function to run the appropriate commands and reset the counter
execute if score 15t uft_data <= 0 svl_value run function uft:run/15t



# Next =>
# Subtracts "1" from the counter
scoreboard players operation 16t uft_data -= 1 svl_value

# If the score is "0", runs a function to run the appropriate commands and reset the counter
execute if score 16t uft_data <= 0 svl_value run function uft:run/16t



# Next =>
# Subtracts "1" from the counter
scoreboard players operation 17t uft_data -= 1 svl_value

# If the score is "0", runs a function to run the appropriate commands and reset the counter
execute if score 17t uft_data <= 0 svl_value run function uft:run/17t



# Next =>
# Subtracts "1" from the counter
scoreboard players operation 18t uft_data -= 1 svl_value

# If the score is "0", runs a function to run the appropriate commands and reset the counter
execute if score 18t uft_data <= 0 svl_value run function uft:run/18t



# Next =>
# Subtracts "1" from the counter
scoreboard players operation 19t uft_data -= 1 svl_value

# If the score is "0", runs a function to run the appropriate commands and reset the counter
execute if score 19t uft_data <= 0 svl_value run function uft:run/19t



# Next =>
# Subtracts "1" from the counter
scoreboard players operation 20t uft_data -= 1 svl_value

# If the score is "0", runs a function to run the appropriate commands and reset the counter
execute if score 20t uft_data <= 0 svl_value run function uft:run/20t